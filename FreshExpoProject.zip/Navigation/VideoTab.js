import React from 'react';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import Videos from '../Screen/Video/Videos';
import FreeVideo from '../Screen/Video/FreeVideo';
import CompletedVideo from '../Screen/Video/CompletedVideo';
import PausedVideo from '../Screen/Video/PausedVideo';

const VideoTop = createMaterialTopTabNavigator();

export  const VideoTab = () =>{
	return (
    <VideoTop.Navigator
      initialRouteName="Videos"
      tabBarOptions={{
         activeTintColor: 'black',
        inactiveTintColor:'#1ca6d1',
        labelStyle: { fontSize: 8 },
        style: {height:38, backgroundColor: '#ffffff' },
      }}
    >
      <VideoTop.Screen
        name="Videos"
        component={Videos}
        options={{ tabBarLabel: 'All',title:'Videos' }}
      />
      <VideoTop.Screen
        name="FreeVideo"
        component={FreeVideo}
        options={{ tabBarLabel: 'Free' ,title:'Free Videos'}}
      />
      <VideoTop.Screen
        name="CompletedVideo"
        component={CompletedVideo}
        options={{ tabBarLabel: 'Completed',title:'Complete Videos' }}
      />
       <VideoTop.Screen
        name="PausedVideo"
        component={PausedVideo}
        options={{ tabBarLabel: 'Paused',title:'Paused Video' }}
      />
    </VideoTop.Navigator>
  );
}
/*
$('#txtnumber').keydown(function(e) {
     var key = e.charCode || e.keyCode || 0;
     $text = $(this);
     if (key !== 8 && key !== 9) {
       if ($text.val().length === 3) {
         $text.val($text.val() + '-');
       }
       if ($text.val().length === 7) {
         $text.val($text.val() + '-');
       }

     }

     return (key == 8 || key == 9 || key == 46 || (key >= 48 && key <= 57) || (key >= 96 && key <= 105));
   })

$sql = "SELECT `userid`,`first_name`,`last_name` FROM `employee`";  
$setRec = mysqli_query($conn, $sql);  
$columnHeader = '';  
$columnHeader = "User Id" . "\t" . "First Name" . "\t" . "Last Name" . "\t";  
$setData = '';  
  while ($rec = mysqli_fetch_row($setRec)) {  
    $rowData = '';  
    foreach ($rec as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;  
    }  
    $setData .= trim($rowData) . "\n";  
}  
  
header("Content-type: application/octet-stream");  
header("Content-Disposition: attachment; filename=User_Detail.xls");  
header("Pragma: no-cache");  
header("Expires: 0");  

  echo ucwords($columnHeader) . "\n" . $setData . "\n";

*/