'use strict';

import React, { Component } from 'react';

import {
  StyleSheet,
  View,
  Text
} from 'react-native';
import {Constant} from '../Constant';
import axios from 'axios';
class AboutUs extends Component {
  render() {
    return (
      <View >
      <Text>About Page</Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({

});


export default AboutUs;