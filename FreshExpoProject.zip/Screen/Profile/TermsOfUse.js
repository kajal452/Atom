'use strict';

import React, { Component } from 'react';

import {
  StyleSheet,
  View,
  Text,
} from 'react-native';
import {Constant} from '../Constant';
import axios from 'axios';
class TermsOfUse extends Component {
  render() {
    return (
      <View >
      <Text>TermsOfUse Page</Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({

});


export default TermsOfUse;