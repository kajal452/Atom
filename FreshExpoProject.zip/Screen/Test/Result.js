'use strict';

import React, { Component } from 'react';

import {
  StyleSheet,
  View,
} from 'react-native';
import {Constant} from '../Constant';
import axios from 'axios';
class Result extends Component {
  render() {
    return (
      <View />
    );
  }
}

const styles = StyleSheet.create({

});


export default Result;